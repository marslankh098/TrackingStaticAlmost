package a.hilt.osmars2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;

public class MakerMyAppAds {

    public static boolean shouldShowAdmob = false;
    public static String interstitial_admob_inApp = MyApplication.Companion.getStr(R.string.admob_interstitial_ad_id);
    public static boolean haveGotSnapshot = false;

    public static boolean ctr_control = false;
    public static boolean canReLoadedMoPubAd = false;
    public static boolean canReLoadedAdMob = false;
    private static boolean canReLoadedMax = false;
    /*    public static MoPubInterstitial moPubInterstitial;*/
    public static InterstitialAd admobInterstitialAd;
    public static boolean shouldGoForAds = true;

    public static long next_ads_time = 10000;
    public static double current_counter = 7;
    public static boolean shouldShowAppOpen = true;
    public static boolean shouldShowBannerNative = true;
    public static InterstitialAd admobInterstitialAdSplash;
    public static int ads_after = 0;
    public static int current_ad = 5;

     private static final Handler myHandler = new Handler();

    public static void setHandlerForAd() {
        shouldGoForAds = false;
        Log.d("ConstantAdsLoadAds", "shouldGoForAds onTimeStart: " + shouldGoForAds);
        myHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                shouldGoForAds = false;
                Log.d("ConstantAdsLoadAds", "shouldGoForAds onTimeComplete: " + shouldGoForAds);
            }
        }, next_ads_time);
    }

    public static AdSize getAdSize(Activity context) {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = context.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth);
    }

    @SuppressLint("MissingPermission")
    private static void loadInvitaionCardMakerAdMobBanner(final LinearLayout adContainer, final AdView mAdView, final Context context) {

        Log.d("ConstantAdsLoadAds", "Banner AdMob requesting");

        if (shouldShowBannerNative) {
            try {
                mAdView.setAdSize(getAdSize(((Activity) context)));
                mAdView.loadAd(new AdRequest.Builder().build());
            } catch (Exception e) {
                e.printStackTrace();
            }
            mAdView.setAdListener(new com.google.android.gms.ads.AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    Log.d("ConstantAdsLoadAds", "Banner AdMob Loaded");
                    try {
                        adContainer.removeAllViews();
                        adContainer.addView(mAdView);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    mAdView.destroy();
                    Log.d("ConstantAdsLoadAds", "loadAdError : " + loadAdError.getMessage());
                    // MakerMyAppAds.loadMoPubBannerAd(adContainer, context);
                 }
            });
        }
    }



}

