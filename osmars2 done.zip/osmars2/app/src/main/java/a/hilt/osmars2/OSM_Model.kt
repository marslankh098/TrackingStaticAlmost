package a.hilt.osmars2

import android.content.Context
import android.preference.PreferenceManager
import org.osmdroid.config.Configuration
import org.osmdroid.views.MapView

class OSM_Model {

    fun settingMap(context: Context,view: MapView){
        Configuration.getInstance().load(context, PreferenceManager.getDefaultSharedPreferences(context))
        view.setBuiltInZoomControls(true);
        view.setMultiTouchControls(true);
        view.controller.zoomTo(6.0)
    }

}