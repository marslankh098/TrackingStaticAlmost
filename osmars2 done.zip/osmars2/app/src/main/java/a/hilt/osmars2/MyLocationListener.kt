package a.hilt.osmars2

import android.location.Location

interface MyLocationListener {
    fun onLocationChanged(location: Location)
}