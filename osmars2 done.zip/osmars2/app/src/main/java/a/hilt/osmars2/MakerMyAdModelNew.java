package a.hilt.osmars2;

public class MakerMyAdModelNew {
    public String appid_admob_inApp;
    public String banner_admob_inApp;
    public String interstitial_admob_inApp;
    public String native_admob_inApp;
    public boolean should_show_admob;
    public boolean ctr_control;
    public double next_ads_time;
    public double current_counter;
    public String app_open_admob_inApp;
    public String app_open_admob_splash_inApp;
    public boolean should_show_app_open;
    public String admob_interstitial_Splash_Inter;
    public   int  ads_after=5;

    public MakerMyAdModelNew() {
    }

    public MakerMyAdModelNew(String appid_admob_inApp, String banner_admob_inApp, String interstitial_admob_inApp, String native_admob_inApp, boolean should_show_admob, boolean ctr_control, double next_ads_time, double current_counter, String app_open_admob_inApp, String app_open_admob_splash_inApp, boolean should_show_app_open, String admob_interstitial_Splash_Inter, int ads_after) {
        this.appid_admob_inApp = appid_admob_inApp;
        this.banner_admob_inApp = banner_admob_inApp;
        this.interstitial_admob_inApp = interstitial_admob_inApp;
        this.native_admob_inApp = native_admob_inApp;
        this.should_show_admob = should_show_admob;
        this.ctr_control = ctr_control;
        this.next_ads_time = next_ads_time;
        this.current_counter = current_counter;
        this.app_open_admob_inApp = app_open_admob_inApp;
        this.app_open_admob_splash_inApp = app_open_admob_splash_inApp;
        this.should_show_app_open = should_show_app_open;
        this.admob_interstitial_Splash_Inter = admob_interstitial_Splash_Inter;
        this.ads_after = ads_after;
    }

    public int getAds_after() {
        return ads_after;
    }

    public void setAds_after(int ads_after) {
        this.ads_after = ads_after;
    }

    public String isAdmob_interstitial_Splash_Inter() {
        return admob_interstitial_Splash_Inter;
    }

    public void setAdmob_interstitial_Splash_Inter(String admob_interstitial_Splash_Inter) {
        this.admob_interstitial_Splash_Inter = admob_interstitial_Splash_Inter;
    }

    public String getApp_open_admob_splash_inApp() {
        return app_open_admob_splash_inApp;
    }

    public void setApp_open_admob_splash_inApp(String app_open_admob_splash_inApp) {
        this.app_open_admob_splash_inApp = app_open_admob_splash_inApp;
    }

    public boolean isShould_show_app_open() {
        return should_show_app_open;
    }

    public void setShould_show_app_open(boolean should_show_app_open) {
        this.should_show_app_open = should_show_app_open;
    }

    public String getApp_open_admob_inApp() {
        return app_open_admob_inApp;
    }

    public void setApp_open_admob_inApp(String app_open_admob_inApp) {
        this.app_open_admob_inApp = app_open_admob_inApp;
    }

    public String getAppid_admob_inApp() {
        return appid_admob_inApp;
    }

    public void setAppid_admob_inApp(String appid_admob_inApp) {
        this.appid_admob_inApp = appid_admob_inApp;
    }

    public String getBanner_admob_inApp() {
        return banner_admob_inApp;
    }

    public void setBanner_admob_inApp(String banner_admob_inApp) {
        this.banner_admob_inApp = banner_admob_inApp;
    }

    public String getInterstitial_admob_inApp() {
        return interstitial_admob_inApp;
    }

    public void setInterstitial_admob_inApp(String interstitial_admob_inApp) {
        this.interstitial_admob_inApp = interstitial_admob_inApp;
    }

    public String getNative_admob_inApp() {
        return native_admob_inApp;
    }

    public void setNative_admob_inApp(String native_admob_inApp) {
        this.native_admob_inApp = native_admob_inApp;
    }

    public boolean isShould_show_admob() {
        return should_show_admob;
    }

    public void setShould_show_admob(boolean should_show_admob) {
        this.should_show_admob = should_show_admob;
    }

    public boolean isCtr_control() {
        return ctr_control;
    }

    public void setCtr_control(boolean ctr_control) {
        this.ctr_control = ctr_control;
    }

    public double getNext_ads_time() {
        return next_ads_time;
    }

    public void setNext_ads_time(double next_ads_time) {
        this.next_ads_time = next_ads_time;
    }



    public double getCurrent_counter() {
        return current_counter;
    }

    public void setCurrent_counter(double current_counter) {
        this.current_counter = current_counter;
    }
}
