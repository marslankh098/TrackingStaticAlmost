package a.hilt.osmars2

import android.annotation.SuppressLint
import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class MyApplication : Application() {

    @SuppressLint("MissingPermission")
    override fun onCreate() {
        super.onCreate()
        instance = this
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        getDataFromFirebase()
    }

    companion object {
        @get:Synchronized
        var instance: MyApplication? = null
            private set

        fun getStr(id: Int): String {
            return instance!!.getString(id)
        }
    }
    private fun getDataFromFirebase() {



    }
}