package a.hilt.osmars2

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import a.hilt.osmars2.databinding.ActivityNavstartScreenBinding
import android.content.res.ColorStateList
import androidx.annotation.RequiresApi
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.gms.maps.model.LatLng
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.osmdroid.bonuspack.routing.OSRMRoadManager
import org.osmdroid.bonuspack.routing.Road
import org.osmdroid.bonuspack.routing.RoadManager
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.ItemizedIconOverlay
import org.osmdroid.views.overlay.ItemizedOverlayWithFocus
import org.osmdroid.views.overlay.OverlayItem
import java.util.ArrayList

class OSMDroidMapActivityArslan : AppCompatActivity(),
    ItemizedIconOverlay.OnItemGestureListener<OverlayItem> {
    private var someActivityResultLauncher: ActivityResultLauncher<Intent>? = null
    private var manager: LocationManager? = null
    private var checkLocationDialog: Dialog? = null
    private var startNavigationLayout: ConstraintLayout? = null
    var TAG = "Navigation:"
    var navBtn: Button? = null
    var address: String? = null
    private var origins: LatLng? = null
    private var destinations: LatLng? = null
    var zoom = 4
    var isRoute = false
    var binding: ActivityNavstartScreenBinding? = null
    var markers: ArrayList<OverlayItem>? = ArrayList()

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityNavstartScreenBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        OSM_Model().settingMap(this, binding!!.mapView)

        origins = LatLng(33.6844, 73.0479)
        destinations = LatLng(33.738045, 73.084488)
        address = "F-11 Sector, Islamabad"

        Handler().postDelayed({
            drawingRoute(destinations!!.latitude, destinations!!.longitude, address)
        }, 2000)
        variableIni()
        setOnClickListener()
        activityResultIntent()

        if (manager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            setValues(R.string.location_enabled, R.drawable.ic_baseline_location_on_24)
        }
    }
    fun drawingRoute(destLat: Double, destLng: Double, address: String?) {
        markers!!.clear()
        if (binding!!.mapView.overlays.size > 0) {
            binding!!.mapView.overlays.clear()
        }
        binding!!.mapView!!.getController().animateTo(GeoPoint(destLat, destLng), 8.5, 1000)

        var start = OverlayItem("Current Location", "", GeoPoint(origins!!.latitude, origins!!.longitude))
        start.setMarker(resources.getDrawable(R.drawable.ic_current_location))
        markers!!.add(start)

        var end = OverlayItem(address, "", GeoPoint(destLat, destLng))
        end.setMarker(resources.getDrawable(R.drawable.ic_current_location))
        markers!!.add(end)

        Log.d("TAGAppLatLngTask", "drawingRoute: " + markers!!.size)
        var overlay = ItemizedOverlayWithFocus<OverlayItem>(this, markers, this)
        overlay.setFocusItemsOnTap(true)
        binding!!.mapView!!.overlays.add(overlay)

        val roadManager: RoadManager = OSRMRoadManager(this, "MY_USER_AGENT")
        val waypoints = ArrayList<GeoPoint>()
        waypoints.add(GeoPoint(markers!![0].point.latitude, markers!![0].point.longitude))
        val endPoint = GeoPoint(destLat, destLng)
        waypoints.add(endPoint)

        GlobalScope.launch {
            Dispatchers.IO
            val road123 = roadManager.getRoad(waypoints)
            if (road123!!.mStatus == Road.STATUS_OK) {
                val durationInSeconds = road123.mDuration
                val durationInMinutes = durationInSeconds / 60.0
                Log.d("arsdur", "arsdur in minutes: $durationInMinutes")

                runOnUiThread {
                    // Update UI with duration
                }
            } else {
                Log.d("TAG123", "Error when loading the road - status=" + road123.mStatus)
            }
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun setOnClickListener() {
        binding!!.gpsDetection.setOnClickListener {
            if (!manager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                buildAlertMessageNoGps()
            } else {
                val snackBar: Snackbar = Snackbar.make(
                    binding!!.mapView,
                    "Location Already Enabled",
                    Snackbar.LENGTH_LONG
                )
                snackBar.setBackgroundTint(getColor(R.color.caribbeangreen))
                snackBar.setTextColor(Color.WHITE)
                snackBar.show()
            }
        }
        binding!!.letNavigate.setOnClickListener {
            if (origins != null && destinations != null) {
                val intent = Intent(this, OsmNavigation::class.java)
                val bundle = Bundle()
                bundle.putDouble("lat", origins!!.latitude)
                bundle.putDouble("lng", origins!!.longitude)
                bundle.putDouble("d_lat", destinations!!.latitude)
                bundle.putDouble("d_lng", destinations!!.longitude)
                intent.putExtras(bundle)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Route is missing", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun variableIni() {
        manager = getSystemService(LOCATION_SERVICE) as LocationManager
        checkLocationDialog = Dialog(this)
        navBtn = binding!!.letNavigate
        startNavigationLayout = binding!!.startNavigationLayout
    }

    private fun buildAlertMessageNoGps() {
        checkLocationDialog!!.setContentView(R.layout.location_check_dialog)
        checkLocationDialog!!.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        checkLocationDialog!!.setCancelable(false)
        checkLocationDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val enable = checkLocationDialog!!.findViewById<Button>(R.id.enable)
        val cancel = checkLocationDialog!!.findViewById<Button>(R.id.cancel)
        enable!!.setOnClickListener {
            try {
                val toTheSettings = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                someActivityResultLauncher!!.launch(toTheSettings)
            } catch (e: Exception) {
            }
        }
        cancel!!.setOnClickListener {
            try {
                checkLocationDialog!!.cancel()
            } catch (e: Exception) {
            }
        }
        checkLocationDialog!!.show()
    }

    private val gpsStateCheck: BroadcastReceiver = object : BroadcastReceiver() {
        @RequiresApi(Build.VERSION_CODES.M)
        override fun onReceive(context: Context, intent: Intent) {
            if (LocationManager.PROVIDERS_CHANGED_ACTION == intent.action) {
                val locationManager =
                    context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                if (!isGpsEnabled) {
                    buildAlertMessageNoGps()
                    setValues(R.string.off, R.drawable.ic_baseline_location_off_24)
                } else {
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun setValues(value: Int, imgValue: Int) {
        binding!!.smallAd.text = getString(value)
        binding!!.smallAd.setCompoundDrawablesWithIntrinsicBounds(
            AppCompatResources.getDrawable(this, imgValue),
            null,
            null,
            null
        )
        binding!!.smallAd.compoundDrawableTintMode = PorterDuff.Mode.SRC_IN
        binding!!.smallAd.compoundDrawableTintList =
            ColorStateList.valueOf(ContextCompat.getColor(this, R.color.green_light))
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun activityResultIntent() {
        someActivityResultLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                val isGPSEnabled = manager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
                if (!isGPSEnabled) {
                    setValues(R.string.location_enabled, R.drawable.ic_baseline_location_on_24)
                }
            }
    }
    override fun onItemSingleTapUp(index: Int, item: OverlayItem?): Boolean {
        TODO("Not yet implemented")
    }
    override fun onItemLongPress(index: Int, item: OverlayItem?): Boolean {
        TODO("Not yet implemented")
    }
}
